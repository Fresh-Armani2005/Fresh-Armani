const sidebar=document.getElementById('sidebar'), overlay=document.getElementById('overlay'), menu=document.getElementById('menu-btn');
menu?.addEventListener('click',()=>{sidebar.classList.toggle('open');overlay.classList.toggle('show')}); overlay?.addEventListener('click',()=>{sidebar.classList.remove('open');overlay.classList.remove('show')});
function openModal(id){document.getElementById(id)?.classList.add('open')}
function closeModal(id){document.getElementById(id)?.classList.remove('open')}
document.querySelectorAll('.modal').forEach(m=>m.addEventListener('click',e=>{if(e.target===m)m.classList.remove('open')}));
function updateClock(){const now=new Date();const date=document.getElementById('side-date'),time=document.getElementById('side-time');if(date)date.textContent=now.toLocaleDateString('en-GH',{weekday:'long',month:'short',day:'numeric',year:'numeric'});if(time)time.textContent=now.toLocaleTimeString('en-GH',{hour:'2-digit',minute:'2-digit',second:'2-digit'});}updateClock();setInterval(updateClock,1000);
function validatePatient(){const dob=document.getElementById('dob');if(dob&&new Date(dob.value)>new Date()){alert('Date of birth cannot be in the future.');return false}return true}
