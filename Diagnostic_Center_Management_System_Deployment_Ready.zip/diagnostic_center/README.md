# Diagnostic Center Management System — Deployment Ready

A Flask + SQLAlchemy diagnostic center management system using HTML, CSS and vanilla JavaScript. This version is prepared for **public web hosting**, so staff can open one URL on a phone or computer and all authorized users can work with the same SQL database.

## Architecture

```text
Phone / Computer
       |
       | HTTPS public URL
       v
Flask + Gunicorn web service
       |
       | SQLAlchemy
       v
Managed PostgreSQL database
```

The application can still run locally with MySQL/MariaDB. For a simple hosted deployment, the included `render.yaml` provisions a Render web service plus PostgreSQL and connects them with `DATABASE_URL`.

Render's Flask deployment documentation uses `pip install -r requirements.txt` and Gunicorn as the production server; Render Postgres exposes a connection string that can be supplied through an environment variable. urlRender Flask deployment guidehttps://render.com/docs/deploy-flask urlRender Postgres connection guidehttps://render.com/docs/postgresql-creating-connecting

## Important: public URL

This project is deployment-ready, but a real public URL is created by the hosting provider after the repository is connected to a hosting account. The code package itself cannot create an external hosting account or claim a live URL that does not yet exist.

Once deployed, Render gives the web service an `onrender.com` URL and serves the Flask app through Gunicorn. urlRender first-deploy documentationhttps://render.com/docs/your-first-deploy

## Fastest deployment: Render Blueprint

1. Put this project in a GitHub repository.
2. In Render, choose **New → Blueprint** and select the repository.
3. Render reads the included `render.yaml`.
4. The Blueprint creates:
   - a Python web service named `diagnostic-center`
   - a PostgreSQL database named `diagnostic-center-db`
   - a generated `SECRET_KEY`
   - a `DATABASE_URL` connected to the Postgres database
   - production cookie/security settings
5. During the initial Blueprint setup, enter values for:
   - `ADMIN_NAME`
   - `ADMIN_EMAIL`
   - `ADMIN_PASSWORD`
6. Deploy.
7. Open the generated public URL on any phone or computer.
8. Sign in with the administrator account you supplied.

Render Blueprints support `fromDatabase` references and `generateValue`/`sync: false` for secrets, so database credentials and the secret key do not need to be committed to Git. urlRender Blueprint specificationhttps://render.com/docs/blueprint-spec urlRender environment variables and secretshttps://render.com/docs/configure-environment-variables

### Render settings if entered manually

- **Build Command:** `pip install -r requirements.txt`
- **Start Command:** `python bootstrap.py && gunicorn --bind 0.0.0.0:$PORT --workers 2 --threads 4 --timeout 120 app:app`
- **Environment:** Python
- **Database variable:** `DATABASE_URL` = the Render Postgres internal connection string
- **Secret:** `SECRET_KEY` = a long random value
- **Production:** `COOKIE_SECURE=true`, `FLASK_DEBUG=false`

Use the internal database connection string when the web service and Postgres database are in the same Render environment/region. urlRender Postgres connection stringshttps://render.com/tutorials/postgres-on-render/connection-strings

## Environment variables

### Required in production

```text
SECRET_KEY=<long random secret>
DATABASE_URL=<managed PostgreSQL connection string>
COOKIE_SECURE=true
FLASK_DEBUG=false
ENVIRONMENT=production
APP_NAME=Diagnostic Center Management System
ADMIN_NAME=<administrator name>
ADMIN_EMAIL=<administrator email>
ADMIN_PASSWORD=<strong administrator password>
```

### Local development example

Copy `.env.example` to `.env` and fill in the values. Do not commit `.env` to Git.

```text
DATABASE_URL=mysql+pymysql://root:YOUR_PASSWORD@localhost/diagnostic_center
SECRET_KEY=replace-with-a-long-random-secret
COOKIE_SECURE=false
FLASK_DEBUG=true
ENVIRONMENT=development
```

The application accepts both MySQL/MariaDB and PostgreSQL SQLAlchemy URLs. Render's `postgres://`/`postgresql://` connection strings are normalized automatically to the psycopg SQLAlchemy driver.

## Production database initialization

`bootstrap.py` is safe to run more than once. It:

- creates missing SQL tables
- creates the first administrator only if that email does not already exist
- creates the standard diagnostic test catalog if the test table is empty
- does **not** create fake patient or appointment records in production

The production start command runs `bootstrap.py` before Gunicorn, so the deployed administrator does not need to run Python commands manually.

## Local run

```powershell
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

Set your local variables, then:

```powershell
python bootstrap.py
python app.py
```

Open:

```text
http://127.0.0.1:5000
```

## Production server

Do not use Flask's development server for the public deployment. The project includes Gunicorn and the Render start command uses Gunicorn to serve `app:app`. Render's current Flask guide also uses Gunicorn for production. citeturn0search0turn0search6

## Routes

- `/` — public entry point; sends visitors to the mobile-friendly sign-in page or dashboard
- `/login` — staff login
- `/dashboard` — authenticated dashboard
- `/patients/` — patient management
- `/appointments/` — appointment management
- `/tests/` — diagnostic test catalog
- `/laboratory/` — laboratory worklist/result workflow
- `/reports/` — reports
- `/profile/` — user profile
- `/healthz` — deployment health check

## Security improvements included

- Password hashing with Werkzeug
- Flask-Login authentication
- CSRF protection
- HTTP-only session cookies
- SameSite session cookies
- Secure cookies in production
- Proxy-aware HTTPS handling
- Production secret through environment variables
- No production demo passwords in the login screen
- Role-based laboratory/test access already present in the application
- SQLAlchemy connection health checks

## Mobile UI

The sign-in page has been redesigned for phones first, with:

- responsive layout
- large touch-friendly fields/buttons
- password show/hide control
- mobile viewport/theme metadata
- concise secure-sign-in indicator
- responsive branded homepage/login experience
- desktop layout that expands into a two-column welcome/login screen

The authenticated dashboard and application shell also retain responsive sidebar/menu behavior.

## Database migrations

The project includes Flask-Migrate. For future schema changes, use:

```powershell
flask --app app db migrate -m "Describe the change"
flask --app app db upgrade
```

For a first deployment, `bootstrap.py` creates the tables automatically. For later production schema changes, use migrations rather than relying on `create_all()`.

## Files added/updated for deployment

```text
app.py
config.py
bootstrap.py
requirements.txt
.env.example
.gitignore
Procfile
render.yaml
README.md
templates/login.html
templates/base.html
static/css/style.css
routes/dashboard.py
```
