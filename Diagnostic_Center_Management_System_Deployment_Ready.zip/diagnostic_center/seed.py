from datetime import date, time, datetime, timedelta
from app import app
from extensions import db
from models import User, Patient, Appointment, DiagnosticTest, LaboratoryRequest, LaboratoryResult, Notification

def seed():
    with app.app_context():
        db.create_all()
        if User.query.first():
            print('Database already contains data. Nothing seeded.')
            return
        users=[]
        for name,email,role in [('System Administrator','admin@diagnostic.local','admin'),('Receptionist','reception@diagnostic.local','receptionist'),('Lab Technician','lab@diagnostic.local','lab'),('Doctor','doctor@diagnostic.local','doctor')]:
            u=User(name=name,email=email,role=role);u.set_password('admin123');db.session.add(u);users.append(u)
        tests=[]
        test_data=[('CBC','Complete Blood Count','Hematology','Blood','24 hours',35),('FBS','Fasting Blood Sugar','Chemistry','Blood','4 hours',25),('LIPID','Lipid Profile','Chemistry','Blood','24 hours',60),('LFT','Liver Function Test','Chemistry','Blood','24 hours',80),('RFT','Kidney Function Test','Chemistry','Blood','24 hours',80),('UA','Urinalysis','Urinalysis','Urine','4 hours',30),('MAL','Malaria Test','Parasitology','Blood','2 hours',25),('ECG','ECG','Cardiology','—','1 hour',70)]
        for code,name,cat,sample,turn,price in test_data:
            t=DiagnosticTest(test_code=code,name=name,category=cat,sample_type=sample,turnaround_time=turn,price=price,status='Active');db.session.add(t);tests.append(t)
        db.session.flush()
        names=[('Kofi','Owusu','Male','024 123 4567'),('Ama','Serwaa','Female','054 987 6543'),('Kwame','Mensah','Male','020 333 7890'),('Akosua','Adjei','Female','055 222 1111'),('Yaw','Asare','Male','024 555 1212'),('Abena','Osei','Female','027 788 9900'),('Kojo','Boateng','Male','050 345 6789'),('Adwoa','Frimpong','Female','026 456 7890'),('Nana','Yeboah','Male','059 222 3334'),('Esi','Amoah','Female','020 444 5566')]
        patients=[]
        for i,(fn,ln,g,phone) in enumerate(names,1):
            p=Patient(patient_number=f'P{1000+i}',first_name=fn,last_name=ln,gender=g,phone=phone,date_of_birth=date(1985+i%15,1+(i%12),1+(i%25)),email=f'{fn.lower()}.{ln.lower()}@example.com',address='Kumasi, Ghana');db.session.add(p);patients.append(p)
        db.session.flush()
        today=date.today()
        statuses=['Scheduled','In Progress','Scheduled','Completed','Scheduled','Completed','Scheduled','In Progress','Scheduled','Completed']
        for i,p in enumerate(patients):
            a=Appointment(patient_id=p.id,appointment_date=today,appointment_time=time(8+i%9,30),status=statuses[i],created_by=users[1].id);db.session.add(a);db.session.flush()
            lr=LaboratoryRequest(patient_id=p.id,appointment_id=a.id,test_id=tests[i%len(tests)].id,status='Report Ready' if statuses[i]=='Completed' else ('Analyzing' if statuses[i]=='In Progress' else 'Sample Collected'),sample_collected_at=datetime.utcnow());db.session.add(lr)
        db.session.flush()
        for u in users[:3]: db.session.add(Notification(user_id=u.id,title='Welcome',message='Welcome to the Diagnostic Center Management System.'))
        db.session.commit();print('Seed complete. Password for demo users: admin123')

if __name__=='__main__':seed()
