from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from extensions import db
from models import DiagnosticTest

tests_bp=Blueprint('tests', __name__, url_prefix='/tests')

@tests_bp.route('/')
@login_required
def index(): return render_template('tests.html', tests=DiagnosticTest.query.order_by(DiagnosticTest.name).all())

@tests_bp.route('/save', methods=['POST'])
@login_required
def save():
    if current_user.role != 'admin': return ('Forbidden',403)
    test_id=request.form.get('id'); test=db.get_or_404(DiagnosticTest,int(test_id)) if test_id else DiagnosticTest()
    test.test_code=request.form['test_code']; test.name=request.form['name']; test.category=request.form.get('category')
    test.description=request.form.get('description'); test.price=request.form.get('price') or 0; test.sample_type=request.form.get('sample_type')
    test.turnaround_time=request.form.get('turnaround_time'); test.preparation=request.form.get('preparation'); test.status=request.form.get('status','Active')
    db.session.add(test); db.session.commit(); flash('Test saved successfully.','success'); return redirect(url_for('tests.index'))

@tests_bp.route('/<int:test_id>/delete', methods=['POST'])
@login_required
def delete(test_id):
    if current_user.role != 'admin': return ('Forbidden',403)
    test=db.get_or_404(DiagnosticTest,test_id); db.session.delete(test); db.session.commit(); flash('Test deleted successfully.','success'); return redirect(url_for('tests.index'))
