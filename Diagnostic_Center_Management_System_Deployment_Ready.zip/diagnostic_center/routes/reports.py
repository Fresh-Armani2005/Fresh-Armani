from datetime import date
from flask import Blueprint, render_template, request, make_response
from flask_login import login_required
from extensions import db
from models import Appointment, LaboratoryRequest, Patient

reports_bp=Blueprint('reports',__name__,url_prefix='/reports')
@reports_bp.route('/')
@login_required
def index():
    rows=Appointment.query.order_by(Appointment.appointment_date.desc()).limit(100).all()
    return render_template('reports.html', rows=rows, patients=Patient.query.count(), lab=LaboratoryRequest.query.count())

@reports_bp.route('/csv')
@login_required
def csv():
    rows=Appointment.query.order_by(Appointment.appointment_date.desc()).all()
    lines=['ID,Date,Time,Patient,Phone,Status']
    for a in rows: lines.append(f'{a.id},{a.appointment_date},{a.appointment_time},{a.patient.full_name},{a.patient.phone},{a.status}')
    resp=make_response('\n'.join(lines)); resp.headers['Content-Type']='text/csv'; resp.headers['Content-Disposition']='attachment; filename=appointments_report.csv'; return resp
