from datetime import datetime
from flask import Blueprint, render_template, request, jsonify, redirect, url_for, flash
from flask_login import login_required
from sqlalchemy import or_
from extensions import db
from models import Patient

patients_bp = Blueprint('patients', __name__, url_prefix='/patients')

def make_number():
    return f'P{datetime.utcnow().strftime("%Y%m%d%H%M%S%f")[-10:]}'

@patients_bp.route('/')
@login_required
def index():
    q = request.args.get('q','').strip()
    query = Patient.query.order_by(Patient.created_at.desc())
    if q:
        like = f'%{q}%'
        query = query.filter(or_(Patient.first_name.like(like), Patient.last_name.like(like), Patient.phone.like(like), Patient.patient_number.like(like)))
    return render_template('patients.html', patients=query.all(), q=q)

@patients_bp.route('/new', methods=['GET','POST'])
@login_required
def new():
    if request.method == 'POST':
        try:
            data = request.form
            patient = Patient(patient_number=make_number(), first_name=data['first_name'].strip(), last_name=data['last_name'].strip(),
                              date_of_birth=datetime.strptime(data['date_of_birth'], '%Y-%m-%d').date(), gender=data['gender'],
                              phone=data['phone'].strip(), email=data.get('email'), address=data.get('address'),
                              emergency_contact=data.get('emergency_contact'), emergency_phone=data.get('emergency_phone'),
                              medical_notes=data.get('medical_notes'), insurance=data.get('insurance'))
            db.session.add(patient); db.session.commit()
            flash('Patient registered successfully.', 'success')
            return redirect(url_for('patients.index'))
        except Exception as exc:
            db.session.rollback(); flash(f'Could not save patient: {exc}', 'danger')
    return render_template('patient_form.html', patient=None)

@patients_bp.route('/<int:patient_id>/edit', methods=['GET','POST'])
@login_required
def edit(patient_id):
    patient = db.get_or_404(Patient, patient_id)
    if request.method == 'POST':
        try:
            data = request.form
            patient.first_name=data['first_name'].strip(); patient.last_name=data['last_name'].strip()
            patient.date_of_birth=datetime.strptime(data['date_of_birth'], '%Y-%m-%d').date(); patient.gender=data['gender']
            patient.phone=data['phone'].strip(); patient.email=data.get('email'); patient.address=data.get('address')
            patient.emergency_contact=data.get('emergency_contact'); patient.emergency_phone=data.get('emergency_phone')
            patient.medical_notes=data.get('medical_notes'); patient.insurance=data.get('insurance')
            db.session.commit(); flash('Patient updated successfully.', 'success'); return redirect(url_for('patients.index'))
        except Exception as exc:
            db.session.rollback(); flash(f'Could not update patient: {exc}', 'danger')
    return render_template('patient_form.html', patient=patient)

@patients_bp.route('/<int:patient_id>/delete', methods=['POST'])
@login_required
def delete(patient_id):
    patient = db.get_or_404(Patient, patient_id)
    db.session.delete(patient); db.session.commit(); flash('Patient deleted successfully.', 'success')
    return redirect(url_for('patients.index'))

@patients_bp.route('/api')
@login_required
def api_list():
    patients = Patient.query.order_by(Patient.first_name).all()
    return jsonify([{'id':p.id,'patient_number':p.patient_number,'name':p.full_name,'phone':p.phone} for p in patients])
