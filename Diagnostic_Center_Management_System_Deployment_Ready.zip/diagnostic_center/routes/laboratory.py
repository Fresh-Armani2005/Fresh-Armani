from datetime import datetime
from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from extensions import db
from models import LaboratoryRequest, LaboratoryResult

laboratory_bp=Blueprint('laboratory', __name__, url_prefix='/laboratory')

@laboratory_bp.route('/')
@login_required
def index():
    requests=LaboratoryRequest.query.order_by(LaboratoryRequest.created_at.desc()).all()
    counts={s:LaboratoryRequest.query.filter_by(status=s).count() for s in ['Sample Collected','Analyzing','Report Ready','Completed']}
    return render_template('laboratory.html', requests=requests, counts=counts)

@laboratory_bp.route('/<int:req_id>/update', methods=['POST'])
@login_required
def update(req_id):
    req=db.get_or_404(LaboratoryRequest,req_id); status=request.form.get('status','Analyzing'); req.status=status
    req.technician_id=current_user.id; req.sample_collected_at=req.sample_collected_at or datetime.utcnow(); req.notes=request.form.get('notes')
    result=request.form.get('result')
    if result:
        existing=req.results[0] if req.results else LaboratoryResult(request=req, parameter=request.form.get('parameter') or req.test.name)
        existing.result=result; existing.unit=request.form.get('unit'); existing.reference_range=request.form.get('reference_range'); existing.flag=request.form.get('flag','Normal'); existing.notes=request.form.get('result_notes')
        db.session.add(existing)
    db.session.commit(); flash('Laboratory result/status updated.','success'); return redirect(url_for('laboratory.index'))
