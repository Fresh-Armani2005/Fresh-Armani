from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from extensions import db

profile_bp=Blueprint('profile',__name__,url_prefix='/profile')
@profile_bp.route('/', methods=['GET','POST'])
@login_required
def index():
    if request.method=='POST':
        current_user.name=request.form.get('name',current_user.name).strip(); db.session.commit(); flash('Profile updated successfully.','success')
    return render_template('profile.html')
