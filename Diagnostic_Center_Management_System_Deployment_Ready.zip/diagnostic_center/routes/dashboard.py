from datetime import date
from flask import Blueprint, render_template, jsonify
from flask_login import login_required, current_user
from sqlalchemy import func
from extensions import db
from models import Appointment, LaboratoryRequest, Notification

dashboard_bp = Blueprint('dashboard', __name__)

@dashboard_bp.route('/dashboard')
@login_required
def index():
    today = date.today()
    total = Appointment.query.filter_by(appointment_date=today).count()
    waiting = Appointment.query.filter_by(appointment_date=today, status='Scheduled').count()
    in_progress = LaboratoryRequest.query.filter(LaboratoryRequest.status.in_(['Analyzing','In Progress'])).count()
    completed = Appointment.query.filter_by(appointment_date=today, status='Completed').count()
    appointments = Appointment.query.filter_by(appointment_date=today).order_by(Appointment.appointment_time).limit(8).all()
    unread = Notification.query.filter_by(user_id=current_user.id, is_read=False).count()
    return render_template('dashboard.html', total=total, waiting=waiting, in_progress=in_progress,
                           completed=completed, appointments=appointments, unread=unread)

@dashboard_bp.route('/api/dashboard')
@login_required
def api_dashboard():
    today = date.today()
    return jsonify({
        'total': Appointment.query.filter_by(appointment_date=today).count(),
        'waiting': Appointment.query.filter_by(appointment_date=today, status='Scheduled').count(),
        'in_progress': LaboratoryRequest.query.filter(LaboratoryRequest.status.in_(['Analyzing','In Progress'])).count(),
        'completed': Appointment.query.filter_by(appointment_date=today, status='Completed').count(),
    })
