from datetime import datetime, date
from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_required, current_user
from sqlalchemy import or_
from extensions import db
from models import Appointment, Patient, DiagnosticTest, LaboratoryRequest

appointments_bp = Blueprint('appointments', __name__, url_prefix='/appointments')

@appointments_bp.route('/')
@login_required
def index():
    q=request.args.get('q','').strip(); status=request.args.get('status',''); selected_date=request.args.get('date','')
    query=Appointment.query.join(Patient).order_by(Appointment.appointment_date.desc(), Appointment.appointment_time.desc())
    if q:
        like=f'%{q}%'; query=query.filter(or_(Patient.first_name.like(like), Patient.last_name.like(like), Patient.phone.like(like)))
    if status: query=query.filter(Appointment.status==status)
    if selected_date:
        try: query=query.filter(Appointment.appointment_date==datetime.strptime(selected_date,'%Y-%m-%d').date())
        except ValueError: pass
    return render_template('appointments.html', appointments=query.all(), q=q, status=status, selected_date=selected_date, patients=Patient.query.order_by(Patient.first_name).all(), tests=DiagnosticTest.query.filter_by(status='Active').order_by(DiagnosticTest.name).all())

@appointments_bp.route('/new', methods=['POST'])
@login_required
def new():
    try:
        data=request.form
        appointment=Appointment(patient_id=int(data['patient_id']), appointment_date=datetime.strptime(data['appointment_date'],'%Y-%m-%d').date(),
                                appointment_time=datetime.strptime(data['appointment_time'],'%H:%M').time(), status='Scheduled', notes=data.get('notes'), created_by=current_user.id)
        db.session.add(appointment); db.session.flush()
        test_id=data.get('test_id')
        if test_id:
            db.session.add(LaboratoryRequest(patient_id=appointment.patient_id, appointment_id=appointment.id, test_id=int(test_id), status='Sample Collected'))
        db.session.commit(); flash('Appointment created successfully.', 'success')
    except Exception as exc:
        db.session.rollback(); flash(f'Could not create appointment: {exc}', 'danger')
    return redirect(url_for('appointments.index'))

@appointments_bp.route('/<int:appointment_id>/status', methods=['POST'])
@login_required
def status_update(appointment_id):
    appointment=db.get_or_404(Appointment, appointment_id)
    appointment.status=request.form.get('status','Scheduled'); db.session.commit()
    return redirect(url_for('appointments.index'))

@appointments_bp.route('/<int:appointment_id>/delete', methods=['POST'])
@login_required
def delete(appointment_id):
    appointment=db.get_or_404(Appointment, appointment_id); db.session.delete(appointment); db.session.commit()
    flash('Appointment deleted successfully.', 'success'); return redirect(url_for('appointments.index'))

@appointments_bp.route('/api')
@login_required
def api_list():
    rows=Appointment.query.order_by(Appointment.appointment_date.desc(), Appointment.appointment_time).limit(100).all()
    return jsonify([{'id':a.id,'date':a.appointment_date.isoformat(),'time':a.appointment_time.strftime('%H:%M'),'patient':a.patient.full_name,'phone':a.patient.phone,'status':a.status} for a in rows])
