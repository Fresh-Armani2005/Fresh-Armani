CREATE DATABASE IF NOT EXISTS diagnostic_center CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
-- The Flask application creates tables with SQLAlchemy. Run this file first to create the database.
