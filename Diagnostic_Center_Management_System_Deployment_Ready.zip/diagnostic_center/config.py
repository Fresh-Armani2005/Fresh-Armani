import os

def normalize_database_url(url: str) -> str:
    """Normalize common hosted PostgreSQL URLs for SQLAlchemy/psycopg."""
    if not url:
        return url
    if url.startswith('postgres://'):
        url = 'postgresql://' + url[len('postgres://'):]
    if url.startswith('postgresql://'):
        url = 'postgresql+psycopg://' + url[len('postgresql://'):]
    return url


class Config:
    SECRET_KEY = os.getenv('SECRET_KEY', 'dev-only-change-this-secret')
    DATABASE_URL = os.getenv(
        'DATABASE_URL',
        'mysql+pymysql://root:@localhost/diagnostic_center'
    )
    SQLALCHEMY_DATABASE_URI = normalize_database_url(DATABASE_URL)
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {
        'pool_pre_ping': True,
        'pool_recycle': 280,
    }

    # Production/session security. Set COOKIE_SECURE=false for plain HTTP local development.
    COOKIE_SECURE = os.getenv('COOKIE_SECURE', 'false').lower() == 'true'
    SESSION_COOKIE_SECURE = COOKIE_SECURE
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'
    REMEMBER_COOKIE_SECURE = COOKIE_SECURE
    REMEMBER_COOKIE_HTTPONLY = True
    REMEMBER_COOKIE_SAMESITE = 'Lax'

    # Helpful when the app is behind Render's HTTPS reverse proxy.
    PREFERRED_URL_SCHEME = 'https' if COOKIE_SECURE else 'http'

    APP_NAME = os.getenv('APP_NAME', 'Diagnostic Center Management System')
    ENVIRONMENT = os.getenv('FLASK_ENV', os.getenv('ENVIRONMENT', 'production'))
