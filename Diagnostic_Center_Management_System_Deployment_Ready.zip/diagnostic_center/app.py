import os

from flask import Flask, render_template, redirect, url_for
from flask_login import current_user
from werkzeug.middleware.proxy_fix import ProxyFix

from config import Config
from extensions import db, login_manager, migrate, csrf
from models import User


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    # Render terminates HTTPS at its proxy. Trust the standard proxy headers.
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)

    db.init_app(app)
    login_manager.init_app(app)
    migrate.init_app(app, db)
    csrf.init_app(app)
    login_manager.login_view = 'auth.login'
    login_manager.login_message = 'Please sign in to continue.'
    login_manager.login_message_category = 'warning'

    from routes.auth import auth_bp
    from routes.dashboard import dashboard_bp
    from routes.patients import patients_bp
    from routes.appointments import appointments_bp
    from routes.tests import tests_bp
    from routes.laboratory import laboratory_bp
    from routes.reports import reports_bp
    from routes.profile import profile_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(patients_bp)
    app.register_blueprint(appointments_bp)
    app.register_blueprint(tests_bp)
    app.register_blueprint(laboratory_bp)
    app.register_blueprint(reports_bp)
    app.register_blueprint(profile_bp)

    @login_manager.user_loader
    def load_user(user_id):
        try:
            return db.session.get(User, int(user_id))
        except (TypeError, ValueError):
            return None

    @app.context_processor
    def inject_globals():
        return {
            'app_name': app.config['APP_NAME'],
            'environment': app.config['ENVIRONMENT'],
        }

    @app.route('/')
    def home():
        """Public mobile-friendly entry point for the deployed application."""
        if current_user.is_authenticated:
            return redirect(url_for('dashboard.index'))
        return redirect(url_for('auth.login'))

    @app.route('/healthz')
    def healthz():
        return {'status': 'ok'}

    @app.errorhandler(403)
    def forbidden(_):
        return render_template('error.html', code=403, title='Access denied', message='You do not have permission to view this page.'), 403

    @app.errorhandler(404)
    def not_found(_):
        return render_template('error.html', code=404, title='Page not found', message='The page you requested could not be found.'), 404

    @app.errorhandler(500)
    def server_error(_):
        db.session.rollback()
        return render_template('error.html', code=500, title='Server error', message='Something went wrong. Please try again.'), 500

    return app


app = create_app()

if __name__ == '__main__':
    # Local development only. Production uses Gunicorn.
    app.run(
        host='127.0.0.1',
        port=int(os.getenv('PORT', '5000')),
        debug=os.getenv('FLASK_DEBUG', 'true').lower() == 'true',
    )
