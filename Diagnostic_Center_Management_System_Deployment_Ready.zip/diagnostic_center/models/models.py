from datetime import datetime
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from extensions import db

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(160), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(40), nullable=False, default='receptionist')
    status = db.Column(db.String(20), nullable=False, default='Active')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class Patient(db.Model):
    __tablename__ = 'patients'
    id = db.Column(db.Integer, primary_key=True)
    patient_number = db.Column(db.String(30), unique=True, nullable=False, index=True)
    first_name = db.Column(db.String(80), nullable=False)
    last_name = db.Column(db.String(80), nullable=False)
    date_of_birth = db.Column(db.Date, nullable=False)
    gender = db.Column(db.String(20), nullable=False)
    phone = db.Column(db.String(30), nullable=False)
    email = db.Column(db.String(160))
    address = db.Column(db.String(255))
    emergency_contact = db.Column(db.String(120))
    emergency_phone = db.Column(db.String(30))
    medical_notes = db.Column(db.Text)
    insurance = db.Column(db.String(160))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    appointments = db.relationship('Appointment', back_populates='patient', cascade='all, delete-orphan')
    lab_requests = db.relationship('LaboratoryRequest', back_populates='patient', cascade='all, delete-orphan')

    @property
    def full_name(self):
        return f'{self.first_name} {self.last_name}'

class Appointment(db.Model):
    __tablename__ = 'appointments'
    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patients.id'), nullable=False, index=True)
    appointment_date = db.Column(db.Date, nullable=False, index=True)
    appointment_time = db.Column(db.Time, nullable=False)
    status = db.Column(db.String(30), nullable=False, default='Scheduled', index=True)
    notes = db.Column(db.Text)
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    patient = db.relationship('Patient', back_populates='appointments')
    creator = db.relationship('User', foreign_keys=[created_by])
    lab_requests = db.relationship('LaboratoryRequest', back_populates='appointment', cascade='all, delete-orphan')

class DiagnosticTest(db.Model):
    __tablename__ = 'tests'
    id = db.Column(db.Integer, primary_key=True)
    test_code = db.Column(db.String(30), unique=True, nullable=False)
    name = db.Column(db.String(160), nullable=False)
    category = db.Column(db.String(100))
    description = db.Column(db.Text)
    price = db.Column(db.Numeric(10,2), default=0)
    sample_type = db.Column(db.String(100))
    turnaround_time = db.Column(db.String(80))
    preparation = db.Column(db.Text)
    status = db.Column(db.String(20), default='Active')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    lab_requests = db.relationship('LaboratoryRequest', back_populates='test')

class LaboratoryRequest(db.Model):
    __tablename__ = 'laboratory_requests'
    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patients.id'), nullable=False, index=True)
    appointment_id = db.Column(db.Integer, db.ForeignKey('appointments.id'))
    test_id = db.Column(db.Integer, db.ForeignKey('tests.id'), nullable=False)
    sample_collected_at = db.Column(db.DateTime)
    status = db.Column(db.String(30), nullable=False, default='Sample Collected', index=True)
    technician_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    patient = db.relationship('Patient', back_populates='lab_requests')
    appointment = db.relationship('Appointment', back_populates='lab_requests')
    test = db.relationship('DiagnosticTest', back_populates='lab_requests')
    technician = db.relationship('User', foreign_keys=[technician_id])
    results = db.relationship('LaboratoryResult', back_populates='request', cascade='all, delete-orphan')

class LaboratoryResult(db.Model):
    __tablename__ = 'laboratory_results'
    id = db.Column(db.Integer, primary_key=True)
    laboratory_request_id = db.Column(db.Integer, db.ForeignKey('laboratory_requests.id'), nullable=False)
    parameter = db.Column(db.String(120), nullable=False)
    result = db.Column(db.String(160))
    unit = db.Column(db.String(60))
    reference_range = db.Column(db.String(120))
    flag = db.Column(db.String(30), default='Normal')
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    request = db.relationship('LaboratoryRequest', back_populates='results')

class Notification(db.Model):
    __tablename__ = 'notifications'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    title = db.Column(db.String(160), nullable=False)
    message = db.Column(db.Text, nullable=False)
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    user = db.relationship('User')
