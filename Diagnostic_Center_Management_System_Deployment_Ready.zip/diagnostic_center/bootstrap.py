"""Production-safe database bootstrap.

Creates tables if they do not exist and creates the first administrator from
environment variables. It is intentionally idempotent so Render can run it
before every web-service start.
"""
import os

from app import app
from extensions import db
from models import User, DiagnosticTest


def bootstrap():
    with app.app_context():
        db.create_all()

        email = os.getenv('ADMIN_EMAIL', 'admin@diagnostic.local').strip().lower()
        password = os.getenv('ADMIN_PASSWORD', '').strip()
        name = os.getenv('ADMIN_NAME', 'System Administrator').strip()

        if not password:
            # Never create a known default production password.
            print('ADMIN_PASSWORD is not set; database tables were created, but no admin user was created.')
            return

        user = User.query.filter_by(email=email).first()
        if user is None:
            user = User(name=name, email=email, role='admin', status='Active')
            user.set_password(password)
            db.session.add(user)
            print(f'Created administrator account: {email}')
        else:
            print(f'Administrator account already exists: {email}')

        # Add the built-in test catalog only when the database is completely new.
        # Patient/appointment demo records are intentionally NOT created in production.
        if DiagnosticTest.query.count() == 0:
            catalog = [
                ('CBC', 'Complete Blood Count', 'Hematology', 'Blood', '24 hours', 35),
                ('FBS', 'Fasting Blood Sugar', 'Chemistry', 'Blood', '4 hours', 25),
                ('LIPID', 'Lipid Profile', 'Chemistry', 'Blood', '24 hours', 60),
                ('LFT', 'Liver Function Test', 'Chemistry', 'Blood', '24 hours', 80),
                ('RFT', 'Kidney Function Test', 'Chemistry', 'Blood', '24 hours', 80),
                ('UA', 'Urinalysis', 'Urinalysis', 'Urine', '4 hours', 30),
                ('MAL', 'Malaria Test', 'Parasitology', 'Blood', '2 hours', 25),
                ('ECG', 'ECG', 'Cardiology', '—', '1 hour', 70),
            ]
            for code, test_name, category, sample, turnaround, price in catalog:
                db.session.add(DiagnosticTest(
                    test_code=code, name=test_name, category=category,
                    sample_type=sample, turnaround_time=turnaround,
                    price=price, status='Active'
                ))
            print('Created the default diagnostic test catalog.')

        db.session.commit()


if __name__ == '__main__':
    bootstrap()
