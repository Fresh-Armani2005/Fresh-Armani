from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import json
import os
from datetime import datetime

app = Flask(__name__)
CORS(app)

# Offline conditions
conditions = [
    {
        "symptoms": ["fever", "cough", "tiredness"],
        "diagnosis": "Possible Flu or COVID-19",
        "severity": "Moderate",
        "advice": "Stay hydrated and rest. Consult a doctor if symptoms worsen."
    },
    {
        "symptoms": ["headache", "nausea", "sensitivity to light"],
        "diagnosis": "Possible Migraine",
        "severity": "Mild",
        "advice": "Rest in a dark, quiet room. Consider over-the-counter pain relief."
    },
    {
        "symptoms": ["sore throat", "runny nose", "sneezing"],
        "diagnosis": "Common Cold",
        "severity": "Mild",
        "advice": "Drink warm fluids and get plenty of rest."
    },
    {
        "symptoms": ["chest pain", "shortness of breath"],
        "diagnosis": "Possible Heart Attack – Seek Emergency Help",
        "severity": "Severe",
        "advice": "Call emergency services or go to the nearest hospital now."
    },
    {
        "symptoms": ["abdominal pain", "diarrhea", "vomiting"],
        "diagnosis": "Possible Food Poisoning",
        "severity": "Moderate",
        "advice": "Rehydrate regularly. Seek medical help if vomiting persists."
    },
    {
        "symptoms": ["joint pain", "fatigue", "rash"],
        "diagnosis": "Possible Autoimmune Disease (e.g. Lupus)",
        "severity": "Moderate",
        "advice": "Schedule tests with your healthcare provider."
    },
    {
        "symptoms": ["blurred vision", "frequent urination", "increased thirst"],
        "diagnosis": "Possible Diabetes",
        "severity": "Moderate",
        "advice": "Consult for blood sugar testing."
    },
    {
        "symptoms": ["persistent sadness", "loss of interest", "fatigue"],
        "diagnosis": "Possible Depression",
        "severity": "Mild",
        "advice": "Seek mental health support and counseling."
    },
    {
        "symptoms": ["dizziness", "rapid heartbeat", "shortness of breath"],
        "diagnosis": "Possible Anemia",
        "severity": "Moderate",
        "advice": "Consider blood tests to check iron levels."
    },
    {
        "symptoms": ["swelling in legs", "shortness of breath", "fatigue"],
        "diagnosis": "Possible Heart Failure",
        "severity": "Severe",
        "advice": "Seek urgent medical evaluation."
    },
    {
        "symptoms": ["weight loss", "night sweats", "persistent cough"],
        "diagnosis": "Possible Tuberculosis",
        "severity": "Severe",
        "advice": "Visit a hospital for diagnostic tests."
    },
    {
        "symptoms": ["itchy skin", "rash", "sneezing"],
        "diagnosis": "Possible Allergies",
        "severity": "Mild",
        "advice": "Avoid allergens and consider antihistamines."
    },
    {
        "symptoms": ["muscle weakness", "difficulty breathing", "double vision"],
        "diagnosis": "Possible Myasthenia Gravis",
        "severity": "Severe",
        "advice": "Seek immediate neurological evaluation."
    },
    {
        "symptoms": ["nausea", "upper right abdominal pain", "jaundice"],
        "diagnosis": "Possible Gallstones or Liver Problem",
        "severity": "Moderate",
        "advice": "Consult a gastroenterologist."
    },
    {
        "symptoms": ["frequent urination", "pelvic pain", "burning sensation during urination"],
        "diagnosis": "Possible Urinary Tract Infection (UTI)",
        "severity": "Mild",
        "advice": "Drink plenty of fluids and seek medical treatment."
    },
    {
        "symptoms": ["sudden confusion", "slurred speech", "numbness on one side"],
        "diagnosis": "Possible Stroke – Emergency Situation",
        "severity": "Severe",
        "advice": "Call emergency services immediately."
    },
    {
        "symptoms": ["back pain", "leg numbness", "muscle weakness"],
        "diagnosis": "Possible Herniated Disc",
        "severity": "Moderate",
        "advice": "Consult an orthopedic specialist."
    },
    {
        "symptoms": ["persistent cough", "wheezing", "shortness of breath"],
        "diagnosis": "Possible Asthma",
        "severity": "Moderate",
        "advice": "Use prescribed inhalers and consult a physician."
    },
    {
        "symptoms": ["neck stiffness", "high fever", "severe headache"],
        "diagnosis": "Possible Meningitis",
        "severity": "Severe",
        "advice": "Seek emergency medical care immediately."
    },
    {
        "symptoms": ["abdominal bloating", "irregular bowel movements", "abdominal pain"],
        "diagnosis": "Possible Irritable Bowel Syndrome (IBS)",
        "severity": "Mild",
        "advice": "Monitor diet and consult your doctor for management."
    }
]


def save_patient_record(symptoms, diagnosis_result):
    record = {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "symptoms": symptoms,
        "diagnosis": diagnosis_result
    }

    filename = "patients.json"

    if os.path.exists(filename):
        with open(filename, "r") as file:
            records = json.load(file)
    else:
        records = []

    records.append(record)

    with open(filename, "w") as file:
        json.dump(records, file, indent=4)

@app.route('/api/diagnose', methods=['POST'])
def diagnose():
    data = request.get_json()
    input_symptoms = [s.lower().strip() for s in data.get('symptoms', [])]

    possible_matches = []

    for condition in conditions:
        matches = [s for s in condition["symptoms"] if s in input_symptoms]
        if len(matches) >= 2:
            possible_matches.append({
                "diagnosis": condition["diagnosis"],
                "advice": condition["advice"]
            })

    if possible_matches:
        diagnosis_result = possible_matches
    else:
        diagnosis_result = [{
            "diagnosis": "No clear diagnosis found.",
            "advice": "Please consult a medical professional."
        }]

    save_patient_record(input_symptoms, diagnosis_result)

    return jsonify({"result": diagnosis_result})

@app.route('/api/patients', methods=['GET'])
def get_patient_records():
    filename = "patients.json"
    if os.path.exists(filename):
        with open(filename, "r") as file:
            records = json.load(file)
        return jsonify(records)
    else:
        return jsonify([])

@app.route('/api/download_records', methods=['GET'])
def download_patient_records():
    filename = "patients.json"
    if os.path.exists(filename):
        return send_file(filename, as_attachment=True)
    else:
        return jsonify({"message": "No records found."})

if __name__ == '__main__':
    app.run(debug=True)
